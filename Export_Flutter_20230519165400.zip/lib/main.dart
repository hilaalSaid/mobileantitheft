import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/sign-up.dart';
// import 'package:myapp/page-1/about.dart';
// import 'package:myapp/page-1/recoding.dart';
// import 'package:myapp/page-1/home-page.dart';
// import 'package:myapp/page-1/sign-in.dart';
// import 'package:myapp/page-1/image.dart';
// import 'package:myapp/page-1/photo.dart';
// import 'package:myapp/page-1/notification.dart';
// import 'package:myapp/page-1/gps.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
