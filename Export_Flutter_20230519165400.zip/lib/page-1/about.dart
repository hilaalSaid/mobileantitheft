import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // about8Zj (16:556)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup9wevTc1 (PGmSWA2C5z4nxkcvoZ9wEV)
              padding: EdgeInsets.fromLTRB(19*fem, 0*fem, 0*fem, 50*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupmwboNys (PGmQcJ1anibPNCo68sMWBo)
                    margin: EdgeInsets.fromLTRB(42*fem, 0*fem, 166*fem, 37*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // myhealthrecord7Rf (16:504)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 19*fem, 0*fem),
                          child: Text(
                            'My health record',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5714285714*ffem/fem,
                              letterSpacing: -0.4079999924*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupoqy5oJV (PGmQmTQz1CGUdcmygioQY5)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          width: 70*fem,
                          height: 22*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // allrecords85s (16:505)
                                left: 0.5*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 69*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'All records',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5714285714*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvwh7AHT (PGmQt34MRSsQWETFchvwH7)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 178*fem, 38*fem),
                    width: double.infinity,
                    height: 49*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupmfhoTnM (PGmR2Sz15o1MRvvhrfMFHo)
                          margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 20*fem, 2*fem),
                          padding: EdgeInsets.fromLTRB(19*fem, 12.75*fem, 18*fem, 10.75*fem),
                          height: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xaf4c4d4f),
                            borderRadius: BorderRadius.circular(48*fem),
                          ),
                          child: Center(
                            // groupkmT (18:682)
                            child: SizedBox(
                              width: 30*fem,
                              height: 19.5*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-7A5.png',
                                width: 30*fem,
                                height: 19.5*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // aboutTfs (18:680)
                          'ABOUT',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 40*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup97auQ5K (PGmREwdBedHkRrieLH97au)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 683*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupug6rj7b (PGmRemGposEz7w4xMtuG6R)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 28.55*fem, 0*fem),
                          width: 390*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // rectangle2dim (16:503)
                                left: 0*fem,
                                top: 97*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 390*fem,
                                    height: 586*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(40*fem),
                                        color: Color(0xb26e6b6b),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ellipse1iVK (16:508)
                                left: 126*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 145*fem,
                                    height: 147*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/ellipse-1.png',
                                      width: 145*fem,
                                      height: 147*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // ellipse2cqb (16:509)
                                left: 131*fem,
                                top: 5*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 134*fem,
                                    height: 136*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/ellipse-2.png',
                                      width: 134*fem,
                                      height: 136*fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle7Kzu (16:512)
                                left: 24*fem,
                                top: 185*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 350*fem,
                                    height: 70*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                        color: Color(0xffffffff),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x3f000000),
                                            offset: Offset(0*fem, 4*fem),
                                            blurRadius: 2*fem,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle9PUy (16:513)
                                left: 24*fem,
                                top: 360*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 350*fem,
                                    height: 70*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                        color: Color(0xffffffff),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x3f000000),
                                            offset: Offset(0*fem, 4*fem),
                                            blurRadius: 2*fem,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle8giy (16:514)
                                left: 23*fem,
                                top: 272*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 350*fem,
                                    height: 70*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                        color: Color(0xffffffff),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x3f000000),
                                            offset: Offset(0*fem, 4*fem),
                                            blurRadius: 2*fem,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle10B9w (16:515)
                                left: 23*fem,
                                top: 446*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 350*fem,
                                    height: 70*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(10*fem),
                                        color: Color(0xffffffff),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Color(0x3f000000),
                                            offset: Offset(0*fem, 4*fem),
                                            blurRadius: 2*fem,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // abdirahmanmohamedU93 (16:517)
                                left: 81*fem,
                                top: 213*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 239*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'ABDIRAHMAN MOHAMED',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.1*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // abdirahmanmgmailcomX7K (16:519)
                                left: 67*fem,
                                top: 384*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 273*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'abdirahmanm@gmail.com',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.1*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // gmailQB7 (18:602)
                                left: 36*fem,
                                top: 367*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 35*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'Gmail',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.8333333333*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff6f6f6f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // 75X (16:521)
                                left: 103*fem,
                                top: 294*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 136*fem,
                                    height: 22*fem,
                                    child: Text(
                                      '252 62876456',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.1*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff030303),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // namez9K (17:598)
                                left: 36.5*fem,
                                top: 195*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 33*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'NAME',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.8333333333*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff6f6f6f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // phonegnq (23:72)
                                left: 29*fem,
                                top: 279*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 39*fem,
                                    height: 22*fem,
                                    child: Text(
                                      'PHONE',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.8333333333*ffem/fem,
                                        letterSpacing: -0.4079999924*fem,
                                        color: Color(0xff6f6f6f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // buttonAi1 (22:719)
                                left: 23*fem,
                                top: 631*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 343*fem,
                                    height: 52*fem,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xff000000)),
                                      color: Color(0xffffffff),
                                      borderRadius: BorderRadius.circular(6*fem),
                                    ),
                                    child: Center(
                                      child: Center(
                                        child: Text(
                                          'BACK',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 13*ffem,
                                            fontWeight: FontWeight.w900,
                                            height: 1.1725*ffem/fem,
                                            letterSpacing: 0.52*fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupm3wvyQZ (PGmS1ArVLHyEV5fPYCm3WV)
                          margin: EdgeInsets.fromLTRB(0*fem, 221.52*fem, 0*fem, 207.8*fem),
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // vectorUcD (16:525)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60.5*fem),
                                width: 12.2*fem,
                                height: 18.05*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-KFj.png',
                                  width: 12.2*fem,
                                  height: 18.05*fem,
                                ),
                              ),
                              Container(
                                // vectoryos (16:527)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60.5*fem),
                                width: 12.2*fem,
                                height: 18.05*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-zVK.png',
                                  width: 12.2*fem,
                                  height: 18.05*fem,
                                ),
                              ),
                              Container(
                                // vectoruhX (16:526)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 60.5*fem),
                                width: 12.2*fem,
                                height: 18.05*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-4mK.png',
                                  width: 12.2*fem,
                                  height: 18.05*fem,
                                ),
                              ),
                              Container(
                                // vectorqr5 (16:528)
                                width: 12.2*fem,
                                height: 18.05*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-awX.png',
                                  width: 12.2*fem,
                                  height: 18.05*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottommenuZXB (18:654)
              padding: EdgeInsets.fromLTRB(44.89*fem, 12*fem, 34.29*fem, 11*fem),
              width: double.infinity,
              height: 73*fem,
              decoration: BoxDecoration (
                color: Color(0xfffcfcfc),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupfyqdfKK (PGmTnnYWM9JSafbFy5fYQd)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46.06*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorzcV (18:663)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 19*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-brD.png',
                                width: 25.85*fem,
                                height: 19*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // hometab5tq (18:669)
                          'HOME',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupth7kzku (PGmTtnNWnBbbJPekSFtH7K)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40.81*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // biflagfillL45 (18:664)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 33.08*fem,
                              height: 27*fem,
                              child: Image.asset(
                                'assets/page-1/images/bi-flag-fill-5DP.png',
                                width: 33.08*fem,
                                height: 27*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // map2Bo (18:670)
                          margin: EdgeInsets.fromLTRB(1.03*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'MAP',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.3199999928*fem,
                              color: Color(0xff283043),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupzdwm91X (PGmTzcY8eJfNqHpb4LzDWm)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 36.64*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bimap5A5 (18:659)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                          width: 25.85*fem,
                          height: 23.44*fem,
                          child: Image.asset(
                            'assets/page-1/images/bi-map-TEu.png',
                            width: 25.85*fem,
                            height: 23.44*fem,
                          ),
                        ),
                        Text(
                          // pagemHo (18:671)
                          'PAGE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff0e0e0e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouprzkj6ay (PGmU67NyNbGRzYD7zFrZKj)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.22*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectordqo (18:662)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 28*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-1sK.png',
                                width: 25.85*fem,
                                height: 28*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // noticationXRP (18:672)
                          'NOTICATION',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupvjyddzD (PGmUBGu2y3Qkn8pMDzVJYD)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // groupPiV (18:656)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          width: 25.85*fem,
                          height: 25*fem,
                          child: Image.asset(
                            'assets/page-1/images/group.png',
                            width: 25.85*fem,
                            height: 25*fem,
                          ),
                        ),
                        Text(
                          // settinghz5 (18:673)
                          'SETTING',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}