import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // imageXRw (14:337)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroupkzhfrDK (PGmauAXiK5FD8gg5bzKZHf)
              padding: EdgeInsets.fromLTRB(6*fem, 33*fem, 6*fem, 39*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroup72t5AE1 (PGmZocXGnwqMRgReDq72t5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 177*fem, 29.5*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupvvtftQu (PGmZz2PbGJjgbHavcqvvTf)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40*fem, 0*fem),
                          width: 67*fem,
                          height: 43*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-vvtf.png',
                            width: 67*fem,
                            height: 43*fem,
                          ),
                        ),
                        Text(
                          // imageySM (14:359)
                          'IMAGE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 40*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // allresultsWBP (14:255)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 264*fem, 23.5*fem),
                    child: Text(
                      'ALL RESULTS',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.52*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupesb7QXf (PGma8GerMjeGLAAj1iESB7)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 11*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle2w1o (14:256)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-2.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle213qX (14:257)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-21.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle22xhb (14:258)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-22.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup9ximWDK (PGmaJ6hoqtEpLsiDwv9XiM)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 11*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle23qFb (14:259)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-23.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle24Aof (14:260)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-24.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        TextButton(
                          // rectangle25hHo (14:261)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 107*fem,
                            height: 107*fem,
                            child: Image.asset(
                              'assets/page-1/images/rectangle-25-z5B.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup32v1znh (PGmaTBH1muJE1skHaE32v1)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 11*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle26vwF (14:262)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-26.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle274nZ (14:263)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-27.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle28zRK (14:264)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-28.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup1k5kicD (PGmabg2rii3rXzAZjj1k5K)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 11*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle29Fc9 (14:265)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-29.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle210yHF (14:266)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-210.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle211WY5 (14:267)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-211.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupg57brbw (PGmaiRLchst9bRjVWoG57b)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 32*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle212o1P (14:268)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-212.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle213Xi5 (14:269)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-213.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(
                          width: 11*fem,
                        ),
                        Container(
                          // rectangle214S4M (14:270)
                          width: 107*fem,
                          height: 107*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-214.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonyKB (14:271)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 41*fem, 0*fem),
                    width: double.infinity,
                    height: 52*fem,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xff000000)),
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(6*fem),
                    ),
                    child: Center(
                      child: Center(
                        child: Text(
                          'SEE MORE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w900,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.52*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottommenuRBB (14:318)
              padding: EdgeInsets.fromLTRB(44.89*fem, 12*fem, 34.29*fem, 11*fem),
              width: 432*fem,
              height: 73*fem,
              decoration: BoxDecoration (
                color: Color(0xfffcfcfc),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupvkpz7Zo (PGmbbp2eo1ULg9yJ7WvKpZ)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46.06*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorrGV (14:327)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 19*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-Z3T.png',
                                width: 25.85*fem,
                                height: 19*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // hometab7iD (14:332)
                          'HOME',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup94xfSVb (PGmbhorfE3mVPt2nah94XF)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40.81*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // biflagfillBCH (14:328)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 33.08*fem,
                              height: 27*fem,
                              child: Image.asset(
                                'assets/page-1/images/bi-flag-fill-rff.png',
                                width: 33.08*fem,
                                height: 27*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // mapFxq (14:333)
                          margin: EdgeInsets.fromLTRB(1.03*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'MAP',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.3199999928*fem,
                              color: Color(0xff283043),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouplctmk8u (PGmbo4Cv6xXVmtaqjyLCtM)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 36.64*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bimapH8q (14:323)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                          width: 25.85*fem,
                          height: 23.44*fem,
                          child: Image.asset(
                            'assets/page-1/images/bi-map-1Cq.png',
                            width: 25.85*fem,
                            height: 23.44*fem,
                          ),
                        ),
                        Text(
                          // page14q (14:334)
                          'PAGE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff0e0e0e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjmwmXos (PGmbstQCZaD6BqQmHXjMWM)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.22*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorrbF (14:326)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 28*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-WBo.png',
                                width: 25.85*fem,
                                height: 28*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // noticationLWR (14:335)
                          'NOTICATION',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouptuxsfob (PGmbxPGhtMRxE8TP8utuXs)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group2PF (14:320)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          width: 25.85*fem,
                          height: 25*fem,
                          child: Image.asset(
                            'assets/page-1/images/group-FZw.png',
                            width: 25.85*fem,
                            height: 25*fem,
                          ),
                        ),
                        Text(
                          // settingFG1 (14:336)
                          'SETTING',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}