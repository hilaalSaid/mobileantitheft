import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // notificationtFX (22:684)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroup6fc915F (PGmgEgJepHPuvqLU7v6fc9)
              padding: EdgeInsets.fromLTRB(6*fem, 33*fem, 6*fem, 31*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupqugh6sP (PGmeEV9Fx9AdEufqHsquGH)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 49*fem, 29.5*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouptnayECu (PGmeRKAYqo9NNaZFJcTnay)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 13*fem, 0*fem),
                          width: 67*fem,
                          height: 43*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-tnay.png',
                            width: 67*fem,
                            height: 43*fem,
                          ),
                        ),
                        Text(
                          // notificationLmj (22:709)
                          'NOTIFICATION',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 40*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // allresults4xd (22:706)
                    margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 0*fem, 16.5*fem),
                    child: Text(
                      'ALL RESULTS',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.52*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroup66rzkqT (PGmeZJwE5rCuLDJZvr66rZ)
                    margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 161*fem, 64*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group66GYu (22:766)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 98*fem, 0*fem),
                          width: 30*fem,
                          height: 31*fem,
                          child: Image.asset(
                            'assets/page-1/images/group-66.png',
                            width: 30*fem,
                            height: 31*fem,
                          ),
                        ),
                        Container(
                          // notificationnGM (22:784)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          child: Text(
                            'Notification',
                            style: SafeGoogleFont (
                              'Outfit',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.26*ffem/fem,
                              color: Color(0xfffcfdff),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupqmxhVAm (PGmem8vrP1ZqaqXu27Qmxh)
                    margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 15*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(15*fem, 29*fem, 5*fem, 11*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xb26e6b6b),
                      borderRadius: BorderRadius.circular(40*fem),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogrouproupAnh (PGmf2o9RjHEB8TFEaQRouP)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 22*fem),
                          height: 48*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupavud6gM (PGmfAxaVYFX5GutD3jAvUD)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
                                width: 47*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // unsplashplkgcsboiw4RyX (22:770)
                                      left: 0*fem,
                                      top: 6*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 42*fem,
                                          height: 42*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(21*fem),
                                              border: Border.all(color: Color(0xfffdfdfd)),
                                              color: Color(0xffb8b5b5),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/unsplash-plkgcsboiw4-bg.png',
                                                ),
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x1e000000),
                                                  offset: Offset(0*fem, 2*fem),
                                                  blurRadius: 0*fem,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // ellipse37pEy (22:780)
                                      left: 28*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 19*fem,
                                          height: 19*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(9.5*fem),
                                              color: Color(0xffd6433a),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // HGy (22:782)
                                      left: 35*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 6*fem,
                                          height: 13*fem,
                                          child: Text(
                                            '2',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Outfit',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.26*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // iphone8plusy9o (22:790)
                                margin: EdgeInsets.fromLTRB(0*fem, 9*fem, 157*fem, 0*fem),
                                child: Text(
                                  'Iphone 8 plus',
                                  style: SafeGoogleFont (
                                    'Outfit',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.26*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Container(
                                // magot1s (22:775)
                                margin: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 0*fem),
                                child: Text(
                                  '1m ago.',
                                  style: SafeGoogleFont (
                                    'Outfit',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.26*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupnonuQW1 (PGmfMnbnRuVpQamd4Tnonu)
                          margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 29*fem),
                          height: 48*fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupbxyoVnM (PGmfUcjjhXwo4SHNm5bXyo)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                width: 47*fem,
                                height: double.infinity,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // unsplashoqtafyt5ktwd7s (22:771)
                                      left: 0*fem,
                                      top: 6*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 42*fem,
                                          height: 42*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(21*fem),
                                              border: Border.all(color: Color(0xfffdfdfd)),
                                              color: Color(0xffb8b5b5),
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/unsplash-oqtafyt5ktw-bg.png',
                                                ),
                                              ),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x1e000000),
                                                  offset: Offset(0*fem, 2*fem),
                                                  blurRadius: 0*fem,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // ellipse465kZ (22:781)
                                      left: 28*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 19*fem,
                                          height: 19*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(9.5*fem),
                                              color: Color(0xffd6433a),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // ogZ (22:783)
                                      left: 35*fem,
                                      top: 3*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 6*fem,
                                          height: 13*fem,
                                          child: Text(
                                            '2',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Outfit',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w700,
                                              height: 1.26*ffem/fem,
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // androidgkM (23:37)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 191*fem, 4*fem),
                                child: Text(
                                  'Android ',
                                  style: SafeGoogleFont (
                                    'Outfit',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.26*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Container(
                                // hrsagoQRT (22:778)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                child: Text(
                                  '10 Hrs ago.',
                                  style: SafeGoogleFont (
                                    'Outfit',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.26*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupxmxq7qf (PGmfkrmg31uukwcVnBXMxq)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 295*fem),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // unsplasht0nojypgbokSsw (22:772)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 10*fem),
                                width: 42*fem,
                                height: 42*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(21*fem),
                                  border: Border.all(color: Color(0xfffdfdfd)),
                                  color: Color(0xffb8b5b5),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/unsplash-t0nojypgbok-bg.png',
                                    ),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0x1e000000),
                                      offset: Offset(0*fem, 2*fem),
                                      blurRadius: 0*fem,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // iphone13pro7DP (23:39)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 149*fem, 13*fem),
                                child: Text(
                                  'iphone 13 pro',
                                  style: SafeGoogleFont (
                                    'Outfit',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.26*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                              Text(
                                // hrsagoDnD (22:779)
                                '15 Hrs ago.',
                                style: SafeGoogleFont (
                                  'Outfit',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.26*ffem/fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // buttonMtR (22:708)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 343*fem,
                              height: 52*fem,
                              decoration: BoxDecoration (
                                border: Border.all(color: Color(0xff000000)),
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.circular(6*fem),
                              ),
                              child: Center(
                                child: Center(
                                  child: Text(
                                    'BACK',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w900,
                                      height: 1.1725*ffem/fem,
                                      letterSpacing: 0.52*fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottommenuYCD (25:40)
              padding: EdgeInsets.fromLTRB(44.89*fem, 12*fem, 34.29*fem, 11*fem),
              width: 432*fem,
              height: 73*fem,
              decoration: BoxDecoration (
                color: Color(0xfffcfcfc),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupngbodzM (PGmhWyWBwcAqB6XVbGNgBo)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46.06*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorNS9 (25:49)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 19*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-rKo.png',
                                width: 25.85*fem,
                                height: 19*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // hometabSgu (25:55)
                          'HOME',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupor9pAso (PGmhcZBDxMPZvkrrSioR9P)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40.81*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // biflagfillJj7 (25:50)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 33.08*fem,
                              height: 27*fem,
                              child: Image.asset(
                                'assets/page-1/images/bi-flag-fill.png',
                                width: 33.08*fem,
                                height: 27*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // map17j (25:56)
                          margin: EdgeInsets.fromLTRB(1.03*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'MAP',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.3199999928*fem,
                              color: Color(0xff283043),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup7mojJ6q (PGmhhyBsQBNwVbJZT67Moj)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 36.64*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bimapEmB (25:45)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                          width: 25.85*fem,
                          height: 23.44*fem,
                          child: Image.asset(
                            'assets/page-1/images/bi-map-UnH.png',
                            width: 25.85*fem,
                            height: 23.44*fem,
                          ),
                        ),
                        Text(
                          // pageZYZ (25:57)
                          'PAGE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff0e0e0e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogrouprju5hPs (PGmhoPCWr1NK4RkGTTRJU5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.22*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorqFB (25:48)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                          width: 25.85*fem,
                          height: 28*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-YZj.png',
                            width: 25.85*fem,
                            height: 28*fem,
                          ),
                        ),
                        Text(
                          // noticationXth (25:58)
                          'NOTICATION',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroup43gzshf (PGmhtYiaSTWdr2MVhC43gZ)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // groupdB3 (25:42)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          width: 25.85*fem,
                          height: 25*fem,
                          child: Image.asset(
                            'assets/page-1/images/group-oXb.png',
                            width: 25.85*fem,
                            height: 25*fem,
                          ),
                        ),
                        Text(
                          // settingjzm (25:59)
                          'SETTING',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}