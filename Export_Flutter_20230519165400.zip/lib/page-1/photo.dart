import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // photoyLy (18:603)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroupfxy57CH (PGmcqwd8YQFWVgaqaifxY5)
              padding: EdgeInsets.fromLTRB(36*fem, 111.5*fem, 36*fem, 39*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // allresults1YZ (18:625)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 26.5*fem),
                    child: Text(
                      'ALL RESULTS',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w900,
                        height: 1.1725*ffem/fem,
                        letterSpacing: 0.52*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // rectangle25tcM (18:631)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 85*fem),
                    width: 356*fem,
                    height: 523*fem,
                    child: Image.asset(
                      'assets/page-1/images/rectangle-25.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // buttonQah (18:641)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 343*fem,
                        height: 52*fem,
                        decoration: BoxDecoration (
                          border: Border.all(color: Color(0xff000000)),
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(6*fem),
                        ),
                        child: Center(
                          child: Center(
                            child: Text(
                              'BACK',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w900,
                                height: 1.1725*ffem/fem,
                                letterSpacing: 0.52*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // bottommenuEpd (18:605)
              padding: EdgeInsets.fromLTRB(44.89*fem, 12*fem, 34.29*fem, 11*fem),
              width: 432*fem,
              height: 73*fem,
              decoration: BoxDecoration (
                color: Color(0xfffcfcfc),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupaccdK5P (PGmd5SEeWjv6cZih8sAccd)
                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46.06*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectoredT (18:614)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 19*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-6Fw.png',
                                width: 25.85*fem,
                                height: 19*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // hometabXSM (18:620)
                          'HOME',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupuzgy4BP (PGmdArFHxZuUBQAQ9EUZGy)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40.81*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // biflagfillPDf (18:615)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 33.08*fem,
                              height: 27*fem,
                              child: Image.asset(
                                'assets/page-1/images/bi-flag-fill-pDB.png',
                                width: 33.08*fem,
                                height: 27*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // mapTzD (18:621)
                          margin: EdgeInsets.fromLTRB(1.03*fem, 0*fem, 0*fem, 0*fem),
                          child: Text(
                            'MAP',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.3199999928*fem,
                              color: Color(0xff283043),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupyulqmzu (PGmdFvwAGZS7NapoTRYuLq)
                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 36.64*fem, 0*fem),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // bimap7J5 (18:610)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                          width: 25.85*fem,
                          height: 23.44*fem,
                          child: Image.asset(
                            'assets/page-1/images/bi-map-zHs.png',
                            width: 25.85*fem,
                            height: 23.44*fem,
                          ),
                        ),
                        Text(
                          // pagepyB (18:622)
                          'PAGE',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff0e0e0e),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupl3c9LwX (PGmdN1bMz4Lwgiq7r9L3C9)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.22*fem, 0*fem),
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vectorH65 (18:613)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 25.85*fem,
                              height: 28*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector.png',
                                width: 25.85*fem,
                                height: 28*fem,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          // noticationBBT (18:623)
                          'NOTICATION',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupjbp97L1 (PGmdSqneSg2Y6ff3PhjBp9)
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group4m3 (18:607)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                          width: 25.85*fem,
                          height: 25*fem,
                          child: Image.asset(
                            'assets/page-1/images/group-jgZ.png',
                            width: 25.85*fem,
                            height: 25*fem,
                          ),
                        ),
                        Text(
                          // settingZSu (18:624)
                          'SETTING',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            letterSpacing: 0.3199999928*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}