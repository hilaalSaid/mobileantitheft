import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // recodingY5T (16:376)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff50404),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupz1dfeeH (PGmUzAiZjPn5pa1XyKz1Df)
              padding: EdgeInsets.fromLTRB(12*fem, 30*fem, 84.5*fem, 35*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xff010101),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogrouprud3x9B (PGmVCANabUNPG28WugRUd3)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 33.5*fem, 0*fem),
                    width: 67*fem,
                    height: 43*fem,
                    child: Image.asset(
                      'assets/page-1/images/auto-group-rud3.png',
                      width: 67*fem,
                      height: 43*fem,
                    ),
                  ),
                  Text(
                    // recordingenh (16:474)
                    'RECORDING',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 40*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouppvo3AW9 (PGmVV545CdFxhq2FK8pVo3)
              width: double.infinity,
              height: 815*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle2Gp5 (16:436)
                    left: 0*fem,
                    top: 595*fem,
                    child: Align(
                      child: SizedBox(
                        width: 439*fem,
                        height: 159*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(25*fem),
                            color: Color(0xff010101),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle3NcD (16:437)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 428*fem,
                        height: 621*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group1g77 (16:438)
                    left: 32*fem,
                    top: 80*fem,
                    child: Container(
                      width: 330*fem,
                      height: 444*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // ellipse3ayB (16:441)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 21*fem),
                            width: 55*fem,
                            height: 55*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(27.5*fem),
                              color: Color(0xff7d7d7d),
                            ),
                          ),
                          Container(
                            // ellipse1uVf (16:439)
                            margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 267*fem),
                            width: 45*fem,
                            height: 44*fem,
                            child: Image.asset(
                              'assets/page-1/images/ellipse-1-Q4V.png',
                              width: 45*fem,
                              height: 44*fem,
                            ),
                          ),
                          Container(
                            // ellipse2Ryo (16:440)
                            margin: EdgeInsets.fromLTRB(273*fem, 0*fem, 0*fem, 0*fem),
                            width: 57*fem,
                            height: 57*fem,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(28.5*fem),
                              color: Color(0xffc4c4c4),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group2ZKK (16:442)
                    left: 37*fem,
                    top: 223*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 44*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-2.png',
                          width: 45*fem,
                          height: 44*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group3f7T (16:444)
                    left: 37*fem,
                    top: 289*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 44*fem,
                        child: Image.asset(
                          'assets/page-1/images/group-3.png',
                          width: 45*fem,
                          height: 44*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // polygon3A4D (16:446)
                    left: 43.2160644531*fem,
                    top: 90.2160644531*fem,
                    child: Align(
                      child: SizedBox(
                        width: 34.15*fem,
                        height: 34.15*fem,
                        child: Image.asset(
                          'assets/page-1/images/polygon-3.png',
                          width: 34.15*fem,
                          height: 34.15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // polygon4Gd3 (16:447)
                    left: 43*fem,
                    top: 160*fem,
                    child: Align(
                      child: SizedBox(
                        width: 34.15*fem,
                        height: 34.15*fem,
                        child: Image.asset(
                          'assets/page-1/images/polygon-4.png',
                          width: 34.15*fem,
                          height: 34.15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // polygon6CFo (16:448)
                    left: 43*fem,
                    top: 291*fem,
                    child: Align(
                      child: SizedBox(
                        width: 34.15*fem,
                        height: 34.15*fem,
                        child: Image.asset(
                          'assets/page-1/images/polygon-6.png',
                          width: 34.15*fem,
                          height: 34.15*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // wednesdaytPX (16:449)
                    left: 111*fem,
                    top: 178*fem,
                    child: Align(
                      child: SizedBox(
                        width: 62*fem,
                        height: 15*fem,
                        child: Text(
                          'Wednesday',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // oct2021aGM (16:450)
                    left: 111*fem,
                    top: 161*fem,
                    child: Align(
                      child: SizedBox(
                        width: 59*fem,
                        height: 15*fem,
                        child: Text(
                          '3 Oct 2021',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tuesdayTL9 (16:451)
                    left: 111*fem,
                    top: 241*fem,
                    child: Align(
                      child: SizedBox(
                        width: 45*fem,
                        height: 15*fem,
                        child: Text(
                          'Tuesday',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // oct2021xXo (16:452)
                    left: 111*fem,
                    top: 225*fem,
                    child: Align(
                      child: SizedBox(
                        width: 59*fem,
                        height: 15*fem,
                        child: Text(
                          '2 Oct 2021',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff030000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // monday33T (16:453)
                    left: 111*fem,
                    top: 304*fem,
                    child: Align(
                      child: SizedBox(
                        width: 43*fem,
                        height: 15*fem,
                        child: Text(
                          'Monday',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // oct2021YW1 (16:454)
                    left: 111*fem,
                    top: 290*fem,
                    child: Align(
                      child: SizedBox(
                        width: 59*fem,
                        height: 15*fem,
                        child: Text(
                          '1 Oct 2021',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // startrecordingeZ3 (16:455)
                    left: 111*fem,
                    top: 96*fem,
                    child: Align(
                      child: SizedBox(
                        width: 138*fem,
                        height: 24*fem,
                        child: Text(
                          'Start Recording',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // MTT (16:456)
                    left: 327*fem,
                    top: 484*fem,
                    child: Align(
                      child: SizedBox(
                        width: 12*fem,
                        height: 24*fem,
                        child: Text(
                          '+',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle3TmP (16:457)
                    left: 65*fem,
                    top: 237*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 20*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2*fem),
                            color: Color(0xff171111),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle2Mbs (16:458)
                    left: 50*fem,
                    top: 237*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 20*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2*fem),
                            color: Color(0xff171111),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle4fMf (16:459)
                    left: 20*fem,
                    top: 217*fem,
                    child: Align(
                      child: SizedBox(
                        width: 360*fem,
                        height: 56*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0x93c4c4c4),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // xLm (16:460)
                    left: 323*fem,
                    top: 167*fem,
                    child: Align(
                      child: SizedBox(
                        width: 35*fem,
                        height: 17*fem,
                        child: Text(
                          '25:23',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // fFB (16:461)
                    left: 281*fem,
                    top: 234*fem,
                    child: Align(
                      child: SizedBox(
                        width: 83*fem,
                        height: 17*fem,
                        child: Text(
                          '04:50 / 26:07',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff685f5f),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // wiV (16:462)
                    left: 322*fem,
                    top: 297*fem,
                    child: Align(
                      child: SizedBox(
                        width: 35*fem,
                        height: 17*fem,
                        child: Text(
                          '20:59',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle5raZ (16:463)
                    left: 20*fem,
                    top: 532*fem,
                    child: Align(
                      child: SizedBox(
                        width: 360*fem,
                        height: 59*fem,
                        child: Image.asset(
                          'assets/page-1/images/rectangle-5.png',
                          width: 360*fem,
                          height: 59*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle6NYu (16:464)
                    left: 20*fem,
                    top: 534*fem,
                    child: Align(
                      child: SizedBox(
                        width: 76*fem,
                        height: 57*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0x7f8ae5ea),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // nowplayinguHw (16:465)
                    left: 32*fem,
                    top: 546*fem,
                    child: Align(
                      child: SizedBox(
                        width: 46*fem,
                        height: 33*fem,
                        child: Text(
                          'Now\nPlaying',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // oct2021BmF (16:466)
                    left: 111*fem,
                    top: 543*fem,
                    child: Align(
                      child: SizedBox(
                        width: 68*fem,
                        height: 17*fem,
                        child: Text(
                          '2 Oct 2021',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle7se5 (16:467)
                    left: 110*fem,
                    top: 570*fem,
                    child: Align(
                      child: SizedBox(
                        width: 261*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle8nm3 (16:468)
                    left: 110*fem,
                    top: 570*fem,
                    child: Align(
                      child: SizedBox(
                        width: 35*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff279096),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse67YR (16:469)
                    left: 142*fem,
                    top: 565*fem,
                    child: Align(
                      child: SizedBox(
                        width: 15*fem,
                        height: 15*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(7.5*fem),
                            color: Color(0xff51aeb4),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bottommenuqDX (16:483)
                    left: 0*fem,
                    top: 742*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(44.89*fem, 12*fem, 34.29*fem, 11*fem),
                      width: 432*fem,
                      height: 73*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupv3rv6fF (PGmWD8gKWMwhLKPWWuv3rV)
                            margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 46.06*fem, 0*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // vectordQH (16:492)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 25.85*fem,
                                      height: 19*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-62Z.png',
                                        width: 25.85*fem,
                                        height: 19*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // hometabv8V (16:498)
                                  'HOME',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.3199999928*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup8nzbeKP (PGmWK8WKwQEr43Szz68nZB)
                            margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 40.81*fem, 0*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // biflagfillktD (16:493)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 33.08*fem,
                                      height: 27*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/bi-flag-fill-Wz9.png',
                                        width: 33.08*fem,
                                        height: 27*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // mapdBK (16:499)
                                  margin: EdgeInsets.fromLTRB(1.03*fem, 0*fem, 0*fem, 0*fem),
                                  child: Text(
                                    'MAP',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                      letterSpacing: 0.3199999928*fem,
                                      color: Color(0xff283043),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupgkp1XnV (PGmWQsqkX4gwzXg1gdgKp1)
                            margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 36.64*fem, 0*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bimaps5f (16:488)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8.56*fem),
                                  width: 25.85*fem,
                                  height: 23.44*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/bi-map.png',
                                    width: 25.85*fem,
                                    height: 23.44*fem,
                                  ),
                                ),
                                Text(
                                  // pagex77 (16:500)
                                  'PAGE',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.3199999928*fem,
                                    color: Color(0xff0e0e0e),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup74mbszm (PGmWWTWnXougkC1NY674mb)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.22*fem, 0*fem),
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // vectorodX (16:491)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Container(
                                      width: 25.85*fem,
                                      height: 28*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/vector-3CZ.png',
                                        width: 25.85*fem,
                                        height: 28*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  // noticationWH3 (16:501)
                                  'NOTICATION',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.3199999928*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupwdpbSRb (PGmWbHi4zRbHA8qJ5eWDPb)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // groupNKF (16:485)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.03*fem, 10*fem),
                                  width: 25.85*fem,
                                  height: 25*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/group-Mim.png',
                                    width: 25.85*fem,
                                    height: 25*fem,
                                  ),
                                ),
                                Text(
                                  // settingEcM (16:502)
                                  'SETTING',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.3199999928*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // buttonAW1 (22:722)
                    left: 37*fem,
                    top: 652*fem,
                    child: Container(
                      width: 343*fem,
                      height: 52*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xff000000)),
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(6*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'BACK',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w900,
                              height: 1.1725*ffem/fem,
                              letterSpacing: 0.52*fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}