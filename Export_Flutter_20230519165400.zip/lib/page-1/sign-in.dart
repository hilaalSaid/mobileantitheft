import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signinnCu (1:71)
        padding: EdgeInsets.fromLTRB(42*fem, 184*fem, 43*fem, 182*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // signinfGh (1:143)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 179*fem, 105*fem),
              child: Text(
                'Sign In',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 48*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // inputtextADT (1:144)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xaf4c4d4f),
                borderRadius: BorderRadius.circular(8*fem),
              ),
              child: Text(
                'Email',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 16*ffem,
                  fontWeight: FontWeight.w500,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffbdbdbd),
                ),
              ),
            ),
            Container(
              // autogroupnca92Ff (PGmZCTsB3JDH3TWxeDNcA9)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 36*fem),
              padding: EdgeInsets.fromLTRB(7*fem, 10*fem, 6*fem, 5*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xaf4c4d4f),
                borderRadius: BorderRadius.circular(8*fem),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // passwordJU5 (1:160)
                    margin: EdgeInsets.fromLTRB(0*fem, 15*fem, 212*fem, 0*fem),
                    child: Text(
                      'Password',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffbdbdbd),
                      ),
                    ),
                  ),
                  Container(
                    // showD5F (1:161)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
                    child: Text(
                      'Show',
                      textAlign: TextAlign.right,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff0f0e0e),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // buttonprimaryuim (1:155)
              margin: EdgeInsets.fromLTRB(75*fem, 0*fem, 75*fem, 105*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 56*fem,
                  decoration: BoxDecoration (
                    color: Color(0xd1d6dbdf),
                    borderRadius: BorderRadius.circular(100*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      'Sign In',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff0f0e0e),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // group42Y13 (1:146)
              margin: EdgeInsets.fromLTRB(114*fem, 0*fem, 114*fem, 15*fem),
              padding: EdgeInsets.fromLTRB(3.67*fem, 0*fem, 0*fem, 0*fem),
              width: double.infinity,
              height: 44*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // flatcoloriconsgoogleEuT (1:147)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34.67*fem, 0*fem),
                    width: 36.67*fem,
                    height: 36.67*fem,
                    child: Image.asset(
                      'assets/page-1/images/flat-color-icons-google-8eR.png',
                      width: 36.67*fem,
                      height: 36.67*fem,
                    ),
                  ),
                  Container(
                    // whhcircletwitterWc5 (1:152)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                    width: 40*fem,
                    height: 40*fem,
                    child: Image.asset(
                      'assets/page-1/images/whh-circletwitter.png',
                      width: 40*fem,
                      height: 40*fem,
                    ),
                  ),
                ],
              ),
            ),
            Center(
              // donthaveanaccountsignup2KX (1:154)
              child: Container(
                margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                child: TextButton(
                  onPressed: () {},
                  style: TextButton.styleFrom (
                    padding: EdgeInsets.zero,
                  ),
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      style: SafeGoogleFont (
                        'Lato',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.6538001469*ffem/fem,
                        color: Color(0xff0f0e0e),
                      ),
                      children: [
                        TextSpan(
                          text: 'Don’t have an Account',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.6538001469*ffem/fem,
                            color: Color(0xffbdbdbd),
                          ),
                        ),
                        TextSpan(
                          text: ' ',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.6538001469*ffem/fem,
                            color: Color(0xff0f0e0e),
                          ),
                        ),
                        TextSpan(
                          text: 'Sign-up',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.6538001469*ffem/fem,
                            color: Color(0xff1da1f2),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}