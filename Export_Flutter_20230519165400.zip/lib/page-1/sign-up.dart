import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 428;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // signup52d (1:4)
        padding: EdgeInsets.fromLTRB(41*fem, 164*fem, 42*fem, 162*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff010101),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/frame-1.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // signupQMj (1:49)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 157*fem, 64*fem),
              child: Text(
                'Sign Up',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 48*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // group44rzR (1:30)
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // inputtextNxm (1:43)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 14*fem),
                    width: 343*fem,
                    decoration: BoxDecoration (
                      color: Color(0xaf4c4d4f),
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Text(
                      'Name',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffbdbdbd),
                      ),
                    ),
                  ),
                  Container(
                    // inputtextMZo (1:44)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 14*fem),
                    width: 343*fem,
                    decoration: BoxDecoration (
                      color: Color(0xaf4c4d4f),
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Text(
                      'Email',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffbdbdbd),
                      ),
                    ),
                  ),
                  Container(
                    // inputtextoRo (1:45)
                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 1*fem, 16*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 14*fem),
                    width: double.infinity,
                    height: 50*fem,
                    decoration: BoxDecoration (
                      color: Color(0xaf4c4d4f),
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // nameHbs (I1:45;1:19)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 193*fem, 0*fem),
                          child: Text(
                            'Password',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffbdbdbd),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupakgvwpq (PGmPsytkdc4bxUbMATakgV)
                          width: 43*fem,
                          height: double.infinity,
                          child: Center(
                            child: Text(
                              'Show',
                              textAlign: TextAlign.right,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // inputtext1Zo (1:46)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 12*fem),
                    padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 14*fem),
                    width: double.infinity,
                    height: 50*fem,
                    decoration: BoxDecoration (
                      color: Color(0xaf4c4d4f),
                      borderRadius: BorderRadius.circular(8*fem),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // name5Jm (I1:46;1:19)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 126*fem, 0*fem),
                          child: Text(
                            'Confirm Password',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xffbdbdbd),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupvrgqCPP (PGmQ6eCKmMaN9EGwVAVRGq)
                          width: 44*fem,
                          height: double.infinity,
                          child: Text(
                            'Show',
                            textAlign: TextAlign.right,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // checkboxoptionempty6zZ (1:41)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 45*fem, 14*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // checkboxemptyRmw (I1:41;1:8)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                          width: 16*fem,
                          height: 16*fem,
                          child: Image.asset(
                            'assets/page-1/images/checkbox-empty.png',
                            width: 16*fem,
                            height: 16*fem,
                          ),
                        ),
                        RichText(
                          // iwouldliketoreceiveyournewslet (I1:41;1:9)
                          text: TextSpan(
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.1538001469*ffem/fem,
                              color: Color(0xff666666),
                            ),
                            children: [
                              TextSpan(
                                text: 'I read and agree to',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1538001469*ffem/fem,
                                  color: Color(0x75ffffff),
                                ),
                              ),
                              TextSpan(
                                text: ' ',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1538001469*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                              TextSpan(
                                text: 'Terms and Conditions',
                                style: SafeGoogleFont (
                                  'Inter',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1538001469*ffem/fem,
                                  color: Color(0xff1da1f2),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // buttonprimaryvGm (1:42)
                    margin: EdgeInsets.fromLTRB(75*fem, 0*fem, 77*fem, 13*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 56*fem,
                        decoration: BoxDecoration (
                          color: Color(0xd1d6dbdf),
                          borderRadius: BorderRadius.circular(100*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            'Sign Up',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Center(
                    // orhgq (1:31)
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 13*fem),
                      child: Text(
                        'or',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Lato',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.3568166097*ffem/fem,
                          color: Color(0xffe5e5e5),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group43nTP (1:33)
                    margin: EdgeInsets.fromLTRB(115*fem, 0*fem, 116*fem, 11*fem),
                    padding: EdgeInsets.fromLTRB(3.67*fem, 0*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    height: 44*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // flatcoloriconsgoogletWR (1:34)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 33.67*fem, 0*fem),
                          width: 36.67*fem,
                          height: 36.67*fem,
                          child: Image.asset(
                            'assets/page-1/images/flat-color-icons-google.png',
                            width: 36.67*fem,
                            height: 36.67*fem,
                          ),
                        ),
                        Container(
                          // whhcircletwitterae9 (1:39)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/whh-circletwitter-K7K.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Center(
                    // alreadyhaveanaccountsigninJ4M (1:32)
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Lato',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.6538001469*ffem/fem,
                            color: Color(0xff000000),
                          ),
                          children: [
                            TextSpan(
                              text: 'Already have an Account',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.6538001469*ffem/fem,
                                color: Color(0xffcacccd),
                              ),
                            ),
                            TextSpan(
                              text: ' ',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.6538001469*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                            TextSpan(
                              text: 'Sign-in',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w700,
                                height: 1.6538001469*ffem/fem,
                                color: Color(0xff1da1f2),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}